# Tarea 2 Valentina Alarcón, versión final

# Importo los módulos útiles para hacer lo solicitado

import pyglet

from OpenGL.GL import *
import numpy as np
import sys
import os.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tarea2.transformations as tr
import tarea2.basic_shapes as bs
import tarea2.scene_graph3 as sg
import tarea2.shaders as sh
from tarea2.gpu_shape import createGPUShape, GPUShape
from tarea2.obj_handler import read_OBJ
from tarea2.assets_path import getAssetPath


# Defino los modelos 3D en forma de obj que importaré y utilizaré para el grafo de escena
ASSETS = {
    "nave_obj": getAssetPath("naverara.obj"),
    "aro_obj": getAssetPath("aro.obj"),
    "esfera_obj": getAssetPath("esfera.obj"),
    "cubo_obj": getAssetPath("cubo.obj"),
    "spawner_obj": getAssetPath("spawner_final.obj")

}

# Defino las dimensiones que tendrá la ventana
WIDTH, HEIGHT = 800, 800

# creo Controller, que se utilizará al final para los eventos
class Controller(pyglet.window.Window):

    def __init__(self, width, height, title=f"Tarea 2 Valentina Alarcón"):
        super().__init__(width, height, title)
        self.total_time = 0.0
        #self.showAxis = True
        self.pipeline = sh.SimpleModelViewProjectionShaderProgram()


# creo la cámara
class Camera:

    def __init__(self, at = np.array([0.1, 0.1, 0.1]), eye=np.array([1.0, 1.0, 1.0]), up=np.array([0.0, 0.0, 1.0])) -> None:
        self.at = at
        self.eye = eye
        self.up = up

        # En coordenadas esféricas
        self.R = np.sqrt(np.square(self.eye[0]) + np.square(self.eye[1]) + np.square(self.eye[2]))
        self.theta = np.arccos(self.eye[2]/self.R)
        self.phi = np.arctan(self.eye[1]/self.eye[0])

        # Rapideces de movimiento
        self.phi_speed = 0.1
        self.theta_speed = 0.1
        self.R_speed = 0.1

        # Direcciones de movimiento/rotación
        self.phi_direction = 0
        self.theta_direction = 0
        self.R_direction = 0

        # Proyección ortogonal
        self.projection = tr.ortho(-10, 10, -10, 10, -50, 100)

    def update(self,pos_nave):
        # Para que se actualice de acuerdo al movimiento de la nave
        self.R += self.R_speed * self.R_direction
        self.theta += self.theta_speed * self.theta_direction
        self.phi += self.phi_speed * self.phi_direction

        self.eye[0] = self.R * np.sin(self.theta) * np.cos(self.phi) + pos_nave[0]
        self.eye[1] = self.R * np.sin(self.theta) * np.sin(self.phi) + pos_nave[1]
        self.eye[2] = (self.R) * np.cos(self.theta) + pos_nave[2]
        self.at = pos_nave


# La siguiente clase es utilizada para modelar el movimiento de la nave
class Auxiliar:
    def __init__(self, at=np.array([1.1, 0.1, 0.1]), eye=np.array([0.1, 0.1, 0.1])) -> None:

        self.rotation_XY = 0
        self.rotation_XZ = 0

        self.advance = 0
        self.rotate_xy = 0
        self.rotate_xz = 0

        self.rotation_speed = np.pi
        self.movement_speed = 0.1
        self.vx = 1
        self.vy = 1
        self.vz = 1

        self.eye = eye
        self.at = at

        self.transf = [self.eye[0],self.eye[1],self.eye[2]]


    def update(self):
        self.rotation_XY += self.rotation_speed * self.rotate_xy
        self.rotation_XZ += self.rotation_speed * self.rotate_xz
        self.rotation_YZ = 0

        # El ángulo que se define entre X y Z estará acotado: solo 90° hacia arriba y 90° hacia abajo. Esto con tal de que la nave no vaya dada vuelta.
        if self.rotation_XZ > 90:
            self.rotation_XZ = 90
        elif self.rotation_XZ < -90:
            self.rotation_XZ = -90

        self.eye[0] += (self.vx * self.advance*self.movement_speed * np.cos(np.deg2rad(self.rotation_XY))*np.sin(np.deg2rad(self.rotation_XZ+90)))
        self.eye[1] += (self.vy * self.advance*self.movement_speed * np.sin(np.deg2rad(self.rotation_XY))*np.sin(np.deg2rad(self.rotation_XZ+90)))
        self.eye[2] += self.vz*self.advance*self.movement_speed * np.cos(np.deg2rad(self.rotation_XZ+90))
        self.transf = [self.eye[0],self.eye[1],self.eye[2]]
        pass

    def update_circle(self, x, y, dx, dy):
        # Aquí tenemos los comandos que serán útiles para controlar la rotación hacia arriba y abajo, de acuerdo al mouse.
        if dy>1:
            self.rotate_xz = 1
        elif dy<-1:
            self.rotate_xz = -1
        else:
            self.rotate_xz = 0

auxiliar = Auxiliar()
camera = Camera(auxiliar.eye)
controller = Controller(width=WIDTH, height=HEIGHT)


# Describimos el color de la pantalla, activamos la profundidad y le decimos al programa que use el shader de la pipeline creada
glClearColor(0.06, 0.1, 0.31, 1.0)

glEnable(GL_DEPTH_TEST)

glUseProgram(controller.pipeline.shaderProgram)

# Creemos los ejes coordenados:
#cpuAxis = bs.createAxis(8)
#gpuAxis = GPUShape().initBuffers()
#controller.pipeline.setupVAO(gpuAxis)
#gpuAxis.fillBuffers(cpuAxis.vertices, cpuAxis.indices, GL_STATIC_DRAW)

# A continuación se crea el grafo de escena por partes

# El grupo de naves
def crearNaves(pipeline,r,g,b):
    nave_forma = createGPUShape(pipeline,read_OBJ(ASSETS["nave_obj"], (r,g,b)))

    nave_rotada = sg.SceneGraphNode("nave_rotada")
    nave_rotada.transform = tr.matmul([tr.rotationZ(np.pi),tr.rotationX(np.pi/2)])
    nave_rotada.childs += [nave_forma]

    nave_pequena = sg.SceneGraphNode("nave_pequena")
    nave_pequena.transform = tr.matmul([tr.translate(2,0,0),tr.scale(0.25,0.25,0.25)])
    nave_pequena.childs += [nave_rotada]

    nave_pequena_2 = sg.SceneGraphNode("nave_pequena")
    nave_pequena_2.transform = tr.matmul([tr.translate(3.5,0,0),tr.scale(0.25,0.25,0.25)])
    nave_pequena_2.childs += [nave_rotada]

    nave_escalada = sg.SceneGraphNode("nave_escalada")
    nave_escalada.transform = tr.scale(0.4,0.4,0.4)
    nave_escalada.childs += [nave_rotada]


    naves_grupo = sg.SceneGraphNode("naves_grupo")
    naves_grupo.childs += [nave_escalada]
    naves_grupo.childs += [nave_pequena]
    naves_grupo.childs += [nave_pequena_2]


    return naves_grupo

# Las sombras de las naves
def crearSombrasNave(pipeline,r,g,b):
    nave_forma = createGPUShape(pipeline,read_OBJ(ASSETS["nave_obj"], (r,g,b)))

    nave_rotada = sg.SceneGraphNode("nave_rotada")
    nave_rotada.transform = tr.matmul([tr.rotationZ(np.pi),tr.rotationX(np.pi/2)])
    nave_rotada.childs += [nave_forma]

    nave_pequena = sg.SceneGraphNode("nave_pequena")
    nave_pequena.transform = tr.matmul([tr.translate(2,0,0),tr.scale(0.25,0.25,0)])
    nave_pequena.childs += [nave_rotada]

    nave_pequena_2 = sg.SceneGraphNode("nave_pequena")
    nave_pequena_2.transform = tr.matmul([tr.translate(3.5,0,0),tr.scale(0.25,0.25,0)])
    nave_pequena_2.childs += [nave_rotada]

    nave_escalada = sg.SceneGraphNode("nave_escalada")
    nave_escalada.transform = tr.scale(0.4,0.4,0)
    nave_escalada.childs += [nave_rotada]

    naves_grupo = sg.SceneGraphNode("naves_grupo")
    naves_grupo.transform = tr.translate(0,0,-5)
    naves_grupo.childs += [nave_escalada]
    naves_grupo.childs += [nave_pequena]
    naves_grupo.childs += [nave_pequena_2]

    naves_final = sg.SceneGraphNode("naves_final")
    naves_final.childs += [naves_grupo]


    return naves_final

# Los portales
def crearPortalAro(pipeline,r,g,b):
    portal_aro = sg.SceneGraphNode("portal_aro")
    portal_aro.transform = tr.scale(1.1,1.1,1.1)
    aro = createGPUShape(pipeline,read_OBJ(ASSETS["aro_obj"], (r,g,b)))
    portal_aro.childs += [aro]

    portalAroRotado = sg.SceneGraphNode("portalAroRotado")
    portalAroRotado.transform = tr.rotationY(90)
    portalAroRotado.childs += [portal_aro]

    portalAroFinal = sg.SceneGraphNode("portalAroFinal")
    portalAroFinal.transform = tr.translate(-5,0,0)
    portalAroFinal.childs += [portalAroRotado]

    portal = sg.SceneGraphNode("portal")
    portal.childs += [portalAroFinal]
    return portal


# Meteoritos, que funcionan como obstáculo
def crearMeteorito(pipeline,r,g,b):
    esfera = createGPUShape(pipeline,read_OBJ(ASSETS["esfera_obj"], (r,g,b)))

    meteorito_esfera = sg.SceneGraphNode("meteorito_esfera")
    meteorito_esfera.transform = tr.scale(0.7,0.7,0.7)
    meteorito_esfera.childs += [esfera]

    #Situamos el meteorito en algún lado
    meteorito_final = sg.SceneGraphNode("meteorito_final")
    meteorito_final.transform = tr.translate(0.7,1,-1.5)
    meteorito_final.childs += [meteorito_esfera]

    meteorito = sg.SceneGraphNode("meteorito")
    meteorito.childs += [meteorito_final]
    return meteorito


# Un cubo, que simula ser una basura espacial
def crearCuboEspacial(pipeline,r,g,b):
    cubo = createGPUShape(pipeline,read_OBJ(ASSETS["cubo_obj"], (r,g,b)))

    basuraCubo = sg.SceneGraphNode("basuraCubo")
    basuraCubo.transform = tr.scale(0.5, 0.5, 0.5)
    basuraCubo.childs += [cubo]

    basuraCuboRotado = sg.SceneGraphNode("basuraCuboRotado")
    basuraCuboRotado.transform = tr.rotationY(20)
    basuraCuboRotado.childs += [basuraCubo]

    basuraCuboFinal = sg.SceneGraphNode("basuraCuboFinal")
    basuraCuboFinal.transform = tr.translate(-7,-3,0.5)
    basuraCuboFinal.childs += [basuraCuboRotado]

    cuboEspacial = sg.SceneGraphNode("cuboEspacial")
    cuboEspacial.childs += [basuraCuboFinal]
    return cuboEspacial

# Un spawner del cual salen y disparan enemigos
def crearSpawner(pipeline,r,g,b):
    figura = createGPUShape(pipeline,read_OBJ(ASSETS["spawner_obj"], (r,g,b)))

    spawner_tamano = sg.SceneGraphNode("spawner_tamano")
    spawner_tamano.transform = tr.scale(0.7, 0.7, 0.7)
    spawner_tamano.childs += [figura]

    spawnerRotado = sg.SceneGraphNode("spawnerRotado")
    spawnerRotado.transform = tr.rotationX(90)
    spawnerRotado.childs += [spawner_tamano]

    #Instanciamos el portal
    spawnerFinal = sg.SceneGraphNode("spawnerFinal")
    spawnerFinal.transform = tr.translate(0,-4,5)
    spawnerFinal.childs += [spawnerRotado]

    # All pieces together
    spawner = sg.SceneGraphNode("spawner")
    spawner.childs += [spawnerFinal]
    return spawner

#def crearEjes(pipeline):
#    gpu_Axis = sg.SceneGraphNode("gpu_Axis")
#    gpu_Axis.childs += [gpuAxis]

#    return gpu_Axis

# creamos cada objeto con los colores que quiero
naves = crearNaves(controller.pipeline,0.87,0.87,0.87)
sombras = crearSombrasNave(controller.pipeline,0,0,0)
portal_1 = crearPortalAro(controller.pipeline, 0.95, 0, 0.76)
portal_2 = crearPortalAro(controller.pipeline, 0, 0.95, 0.92)
portal_2.transform = tr.matmul([tr.rotationZ(-np.pi/8), tr.translate(11,-4,-5)])
meteorito = crearMeteorito(controller.pipeline, 0.88, 0.47, 0.15)
cubo_espacial = crearCuboEspacial(controller.pipeline, 0.69, 0.7, 0.76)
spawner = crearSpawner(controller.pipeline, 0.47, 0.16, 0.63)
#ejes = crearEjes(controller.pipeline)

# Además, creo un nodo que tenga tanto las naves como las sombras
naves_y_sombra = sg.SceneGraphNode("naves_y_sombra")
naves_y_sombra.childs += [naves]
naves_y_sombra.childs += [sombras]


# Finalmente, lo uno todo en world.
def createWorld(pipeline):
    world = sg.SceneGraphNode("world")
    #world.childs += [naves]
    #world.childs += [sombras]
    world.childs += [naves_y_sombra]
    world.childs += [portal_1]
    world.childs += [portal_2]
    world.childs += [meteorito]
    world.childs += [cubo_espacial]
    world.childs += [spawner]
    #world.childs += [ejes]
    return world

# Y lo situó en la pipeline
world_final = createWorld(controller.pipeline)


# Ahora vemos los eventos
@controller.event
def on_key_press(symbol, modifiers):
    if symbol == pyglet.window.key.W:
        auxiliar.advance = -1
    elif symbol == pyglet.window.key.S:
        auxiliar.advance = 1
    elif symbol == pyglet.window.key.A:
        auxiliar.rotate_xy = 1
    elif symbol == pyglet.window.key.D:
        auxiliar.rotate_xy = -1
    #elif symbol == pyglet.window.key.O:
    #    auxiliar.rotate_xz = 1
    #elif symbol == pyglet.window.key.L:
    #    auxiliar.rotate_xz = -1

@controller.event
def on_key_release(symbol, modifiers):
    if symbol == pyglet.window.key.W:
        auxiliar.advance = 0
    elif symbol == pyglet.window.key.S:
        auxiliar.advance = 0
    elif symbol == pyglet.window.key.A:
        auxiliar.rotate_xy = 0
    elif symbol == pyglet.window.key.D:
        auxiliar.rotate_xy = 0
    #elif symbol == pyglet.window.key.O:
    #    auxiliar.rotate_xz = 0
    #elif symbol == pyglet.window.key.L:
    #    auxiliar.rotate_xz = 0

    elif symbol == pyglet.window.key.ESCAPE:
        controller.close()


@controller.event
# dibujamos todo
def on_draw():
    controller.clear()

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    auxiliar.update()
    camera.update(auxiliar.eye)

    view = tr.lookAt(
        camera.eye,
        camera.at,
        camera.up
    )

    glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "projection"), 1, GL_TRUE, camera.projection)
    glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "view"), 1, GL_TRUE, view)

    naves.transform = tr.matmul([tr.translate(auxiliar.transf[0],auxiliar.transf[1],auxiliar.transf[2]),tr.rotationZ(np.deg2rad(auxiliar.rotation_XY)),tr.rotationY(np.deg2rad(auxiliar.rotation_XZ))])
    sombras.transform = tr.matmul([tr.translate(auxiliar.transf[0],auxiliar.transf[1],auxiliar.transf[2]),tr.rotationZ(np.deg2rad(auxiliar.rotation_XY)),tr.rotationY(np.deg2rad(auxiliar.rotation_XZ))])

    #naves_y_sombra.transform = tr.matmul([tr.translate(auxiliar.transf[0],auxiliar.transf[1],auxiliar.transf[2]),tr.rotationZ(np.deg2rad(auxiliar.rotation_XY)),tr.translate(-auxiliar.transf[0],-auxiliar.transf[1],-auxiliar.transf[2])])
    sg.drawSceneGraphNode(world_final,controller.pipeline, "model")

    glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "model"), 1, GL_TRUE, tr.identity())

# Este es el comando de la acción del mouse
controller.on_mouse_motion = auxiliar.update_circle


if __name__ == '__main__':
    pyglet.app.run()