# Tarea 3 Valentina Alarcón

# Importo los módulos útiles para hacer lo solicitado

import pyglet

from OpenGL.GL import *
import numpy as np
import sys
import os.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tarea2.transformations as tr
import tarea2.basic_shapes as bs
import tarea2.scene_graph3 as sg
import tarea2.shaders as sh
from tarea2.gpu_shape import createGPUShape, GPUShape
from tarea2.obj_handler import read_OBJ
from tarea2.assets_path import getAssetPath
import math
import copy


# Defino los modelos 3D en forma de obj que importaré y utilizaré para el grafo de escena
ASSETS = {
    "nave_obj": getAssetPath("naverara.obj"),
    "aro_obj": getAssetPath("aro.obj"),
    "esfera_obj": getAssetPath("esfera.obj"),
    "cubo_obj": getAssetPath("cubo.obj"),
    "spawner_obj": getAssetPath("spawner_final.obj")

}

# Defino las dimensiones que tendrá la ventana
WIDTH, HEIGHT = 800, 800

ORTOGRAPHIC_PROJECTION = 0
PERSPECTIVE_PROJECTION = 1

PROJECTIONS = [
    tr.ortho(-10, 10, -10, 10, -50, 100),  # ORTOGRAPHIC_PROJECTION 
    tr.perspective(150, float(WIDTH)/float(HEIGHT), 0.7, 100)  # PERSPECTIVE_PROJECTION
]

# creo Controller, que se utilizará al final para los eventos
class Controller(pyglet.window.Window):

    def __init__(self, width, height, title=f"Tarea 3 Valentina Alarcón"):
        super().__init__(width, height, title)
        self.total_time = 0.0
        self.showAxis = True
        self.pipeline = sh.SimpleModelViewProjectionShaderProgram()
        self.step = 0



# creo la cámara
class Camera:

    def __init__(self, at = np.array([0.1, 0.1, 0.1]), eye=np.array([1.0, 1.0, 1.0]), up=np.array([0.0, 0.0, 1.0])) -> None:
        self.at = at
        self.eye = eye
        self.up = up
        #self.C_KEY almacena si es que la tecla C fue apretada (es decir, si se está en perspectiva) o no
        self.C_KEY = False

        # En coordenadas esféricas
        self.R = np.sqrt(np.square(self.eye[0]) + np.square(self.eye[1]) + np.square(self.eye[2]))
        self.theta = np.arccos(self.eye[2]/self.R)
        self.phi = np.arctan(self.eye[1]/self.eye[0])

        # Rapideces de movimiento
        self.phi_speed = 0.1
        self.theta_speed = 0.1
        self.R_speed = 0.1

        # Direcciones de movimiento/rotación
        self.phi_direction = 0
        self.theta_direction = 0
        self.R_direction = 0

        # Projections
        self.available_projections = PROJECTIONS
        self.projection = self.available_projections[ORTOGRAPHIC_PROJECTION]

    def set_projection(self, projection_name):
        self.projection = self.available_projections[projection_name]

    def update(self,pos_nave):
        # Para que se actualice de acuerdo al movimiento de la nave
        self.eye[0] = self.R * np.sin(self.theta) * np.cos(self.phi) + pos_nave[0]
        self.eye[1] = self.R * np.sin(self.theta) * np.sin(self.phi) + pos_nave[1]
        self.eye[2] = (self.R) * np.cos(self.theta) + pos_nave[2]
        self.at = pos_nave

# La siguiente clase es utilizada para modelar el movimiento de la nave
class Auxiliar:
    def __init__(self, at=np.array([1.1, 0.1, 0.1]), eye=np.array([0.1, 0.1, 0.1])) -> None:

        self.rotation_XY = 0
        self.rotation_XZ = 0
        # self.hola activa el modo "andar con la curva"
        self.hola = 0
        # self.curva almacena la curva para dibujar/moverse
        self.curva = 0
        self.N = 500
        self.cant_curvas = 0
        #self.V_KEY almacena si la tecla V está seleccionada o no (es decir, si la curva está dibujada)
        self.V_KEY = False
        #self.M funcionará para la pirueta
        self.M = 25
        #self.pirueta guardará la curva asociada a la pirueta
        self.pirueta = 0
        #self.modo_pirueta activará el modo pirueta tras presionar la tecla asociada
        self.modo_pirueta = 0
        # ahora, creamos un modo auxiliar para desactivar la opción de avanzar con las teclas W/S cuando se necesite
        self.modo_teclas = 1

        self.advance = 0
        self.rotate_xy = 0
        self.rotate_xz = 0

        self.rotation_speed = np.pi
        self.movement_speed = 0.1
        self.vx = 1
        self.vy = 1
        self.vz = 1

        self.eye = eye
        self.at = at

        self.transf = [self.eye[0],self.eye[1],self.eye[2]]


    def update(self):
        self.rotation_XY += self.rotation_speed * self.rotate_xy
        self.rotation_XZ += self.rotation_speed * self.rotate_xz
        self.rotation_YZ = 0

        # El ángulo que se define entre X y Z estará acotado: solo 90° hacia arriba y 90° hacia abajo. Esto con tal de que la nave no vaya dada vuelta.
        if self.rotation_XZ > 90:
            self.rotation_XZ = 90
        elif self.rotation_XZ < -90:
            self.rotation_XZ = -90

        self.eye[0] += (self.vx * self.advance*self.movement_speed * np.cos(np.deg2rad(self.rotation_XY))*np.sin(np.deg2rad(self.rotation_XZ+90)))
        self.eye[1] += (self.vy * self.advance*self.movement_speed * np.sin(np.deg2rad(self.rotation_XY))*np.sin(np.deg2rad(self.rotation_XZ+90)))
        self.eye[2] += self.vz*self.advance*self.movement_speed * np.cos(np.deg2rad(self.rotation_XZ+90))
        self.transf = [self.eye[0],self.eye[1],self.eye[2]]
        pass

    def update_circle(self, x, y, dx, dy):
        # Aquí tenemos los comandos que serán útiles para controlar la rotación hacia arriba y abajo, de acuerdo al mouse.
        if dy>1:
            self.rotate_xz = 1
        elif dy<-1:
            self.rotate_xz = -1
        else:
            self.rotate_xz = 0

auxiliar = Auxiliar()
camera = Camera()
controller = Controller(width=WIDTH, height=HEIGHT)


# Describimos el color de la pantalla, activamos la profundidad y le decimos al programa que use el shader de la pipeline creada
glClearColor(0.06, 0.1, 0.31, 1.0)

glEnable(GL_DEPTH_TEST)

glUseProgram(controller.pipeline.shaderProgram)


# Creemos los ejes coordenados: (estos los usé para guiarme pero no se forman muy bien en verdad)
gpuAxis = createGPUShape(controller.pipeline, bs.createAxis(10))


# A continuación se crea el grafo de escena por partes

# El grupo de naves
def crearNaves(pipeline,r,g,b):
    nave_forma = createGPUShape(pipeline,read_OBJ(ASSETS["nave_obj"], (r,g,b)))

    nave_rotada = sg.SceneGraphNode("nave_rotada")
    nave_rotada.transform = tr.matmul([tr.rotationZ(np.pi),tr.rotationX(np.pi/2)])
    nave_rotada.childs += [nave_forma]

    nave_pequena = sg.SceneGraphNode("nave_pequena")
    nave_pequena.transform = tr.matmul([tr.translate(2,0,0),tr.scale(0.25,0.25,0.25)])
    nave_pequena.childs += [nave_rotada]

    nave_pequena_2 = sg.SceneGraphNode("nave_pequena")
    nave_pequena_2.transform = tr.matmul([tr.translate(3.5,0,0),tr.scale(0.25,0.25,0.25)])
    nave_pequena_2.childs += [nave_rotada]

    nave_escalada = sg.SceneGraphNode("nave_escalada")
    nave_escalada.transform = tr.scale(0.4,0.4,0.4)
    nave_escalada.childs += [nave_rotada]


    naves_grupo = sg.SceneGraphNode("naves_grupo")
    naves_grupo.childs += [nave_escalada]
    naves_grupo.childs += [nave_pequena]
    naves_grupo.childs += [nave_pequena_2]


    return naves_grupo

# Las sombras de las naves
def crearSombrasNave(pipeline,r,g,b):
    nave_forma = createGPUShape(pipeline,read_OBJ(ASSETS["nave_obj"], (r,g,b)))

    nave_rotada = sg.SceneGraphNode("nave_rotada")
    nave_rotada.transform = tr.matmul([tr.rotationZ(np.pi),tr.rotationX(np.pi/2)])
    nave_rotada.childs += [nave_forma]

    nave_pequena = sg.SceneGraphNode("nave_pequena")
    nave_pequena.transform = tr.matmul([tr.translate(2,0,0),tr.scale(0.25,0.25,0)])
    nave_pequena.childs += [nave_rotada]

    nave_pequena_2 = sg.SceneGraphNode("nave_pequena")
    nave_pequena_2.transform = tr.matmul([tr.translate(3.5,0,0),tr.scale(0.25,0.25,0)])
    nave_pequena_2.childs += [nave_rotada]

    nave_escalada = sg.SceneGraphNode("nave_escalada")
    nave_escalada.transform = tr.scale(0.4,0.4,0)
    nave_escalada.childs += [nave_rotada]

    naves_grupo = sg.SceneGraphNode("naves_grupo")
    naves_grupo.transform = tr.translate(0,0,-5)
    naves_grupo.childs += [nave_escalada]
    naves_grupo.childs += [nave_pequena]
    naves_grupo.childs += [nave_pequena_2]

    naves_final = sg.SceneGraphNode("naves_final")
    naves_final.childs += [naves_grupo]


    return naves_final

# Los portales
def crearPortalAro(pipeline,r,g,b):
    portal_aro = sg.SceneGraphNode("portal_aro")
    portal_aro.transform = tr.scale(1.1,1.1,1.1)
    aro = createGPUShape(pipeline,read_OBJ(ASSETS["aro_obj"], (r,g,b)))
    portal_aro.childs += [aro]

    portalAroRotado = sg.SceneGraphNode("portalAroRotado")
    portalAroRotado.transform = tr.rotationY(90)
    portalAroRotado.childs += [portal_aro]

    portalAroFinal = sg.SceneGraphNode("portalAroFinal")
    portalAroFinal.transform = tr.translate(-5,0,0)
    portalAroFinal.childs += [portalAroRotado]

    portal = sg.SceneGraphNode("portal")
    portal.childs += [portalAroFinal]
    return portal


# Meteoritos, que funcionan como obstáculo
def crearMeteorito(pipeline,r,g,b):
    esfera = createGPUShape(pipeline,read_OBJ(ASSETS["esfera_obj"], (r,g,b)))

    meteorito_esfera = sg.SceneGraphNode("meteorito_esfera")
    meteorito_esfera.transform = tr.scale(0.7,0.7,0.7)
    meteorito_esfera.childs += [esfera]

    #Situamos el meteorito en algún lado
    meteorito_final = sg.SceneGraphNode("meteorito_final")
    meteorito_final.transform = tr.translate(0.7,1,-1.5)
    meteorito_final.childs += [meteorito_esfera]

    meteorito = sg.SceneGraphNode("meteorito")
    meteorito.childs += [meteorito_final]
    return meteorito


# Un cubo, que simula ser una basura espacial
def crearCuboEspacial(pipeline,r,g,b):
    cubo = createGPUShape(pipeline,read_OBJ(ASSETS["cubo_obj"], (r,g,b)))

    basuraCubo = sg.SceneGraphNode("basuraCubo")
    basuraCubo.transform = tr.scale(0.5, 0.5, 0.5)
    basuraCubo.childs += [cubo]

    basuraCuboRotado = sg.SceneGraphNode("basuraCuboRotado")
    basuraCuboRotado.transform = tr.rotationY(20)
    basuraCuboRotado.childs += [basuraCubo]

    basuraCuboFinal = sg.SceneGraphNode("basuraCuboFinal")
    basuraCuboFinal.transform = tr.translate(-7,-3,0.5)
    basuraCuboFinal.childs += [basuraCuboRotado]

    cuboEspacial = sg.SceneGraphNode("cuboEspacial")
    cuboEspacial.childs += [basuraCuboFinal]
    return cuboEspacial

# Un spawner del cual salen y disparan enemigos
def crearSpawner(pipeline,r,g,b):
    figura = createGPUShape(pipeline,read_OBJ(ASSETS["spawner_obj"], (r,g,b)))

    spawner_tamano = sg.SceneGraphNode("spawner_tamano")
    spawner_tamano.transform = tr.scale(0.7, 0.7, 0.7)
    spawner_tamano.childs += [figura]

    spawnerRotado = sg.SceneGraphNode("spawnerRotado")
    spawnerRotado.transform = tr.rotationX(90)
    spawnerRotado.childs += [spawner_tamano]

    #Instanciamos el portal
    spawnerFinal = sg.SceneGraphNode("spawnerFinal")
    spawnerFinal.transform = tr.translate(0,-4,5)
    spawnerFinal.childs += [spawnerRotado]

    # All pieces together
    spawner = sg.SceneGraphNode("spawner")
    spawner.childs += [spawnerFinal]
    return spawner



# creamos cada objeto con los colores que quiero
naves = crearNaves(controller.pipeline,0.87,0.87,0.87)
sombras = crearSombrasNave(controller.pipeline,0,0,0)
portal_1 = crearPortalAro(controller.pipeline, 0.95, 0, 0.76)
portal_2 = crearPortalAro(controller.pipeline, 0, 0.95, 0.92)
portal_2.transform = tr.matmul([tr.rotationZ(-np.pi/8), tr.translate(11,-4,-5)])
meteorito = crearMeteorito(controller.pipeline, 0.88, 0.47, 0.15)
cubo_espacial = crearCuboEspacial(controller.pipeline, 0.69, 0.7, 0.76)
spawner = crearSpawner(controller.pipeline, 0.47, 0.16, 0.63)


# Además, creo un nodo que tenga tanto las naves como las sombras
# spoiler: al final no lo ocupé creo, ya que apliqué las transformaciones por separado
naves_y_sombra = sg.SceneGraphNode("naves_y_sombra")
naves_y_sombra.childs += [naves]
naves_y_sombra.childs += [sombras]


# Finalmente, lo uno todo en world.
def createWorld(pipeline):
    world = sg.SceneGraphNode("world")
    world.childs += [naves_y_sombra]
    world.childs += [portal_1]
    world.childs += [portal_2]
    world.childs += [meteorito]
    world.childs += [cubo_espacial]
    world.childs += [spawner]
    return world

# Y lo situó en la pipeline
world_final = createWorld(controller.pipeline)

# Para almacenar los puntos de control, usaremos las siguientes listas inicialmente vacías.
lista_puntos=list()
lista_orient=list()

# Agregaremos las funciones necesarias para trabajar con curvas de Bezier y Hermite

# Funciones de las curvas

def generateT(t):
    return np.array([[1, t, t**2, t**3]]).T


def hermiteMatrix(P1, P2, T1, T2):

    # Genera una matriz de Hermite concatenando las columnas
    G = np.concatenate((P1, P2, T1, T2), axis=1)

    # Debemos tener en cuenta las funciones base asociadas a Hermite
    Mh = np.array([[1, 0, -3, 2], [0, 0, 3, -2], [0, 1, -2, 1], [0, 0, -1, 1]])

    return np.matmul(G, Mh)


def bezierMatrix(P0, P1, P2, P3):

    # Genero una matriz concatenando las columnas
    G = np.concatenate((P0, P1, P2, P3), axis=1)

    # Debo considerar las funciones base asociadas a Bezier
    Mb = np.array([[1, -3, 3, -1], [0, 3, -6, 3], [0, 0, 3, -3], [0, 0, 0, 1]])

    return np.matmul(G, Mb)

# M es la matriz de la curva cúbica, N es el número de muestras entre 0 y 1
def evalCurve(M, N):
    # El parámetro t debe moverse entre 0 y 1, y se formarán los valores intermedios de acuerdo al N escogido por medio de interpolación
    ts = np.linspace(0.0, 1.0, N)

    curve = np.ndarray(shape=(N, 3), dtype=float)

    for i in range(len(ts)):
        T = generateT(ts[i])
        curve[i, 0:3] = np.matmul(M, T).T

    return curve

# Para definir la pirueta, quiero que mi nave de una vuelta de 360° (con un pequeño twist) alrededor de un eje paralelo al eje y
# Donde el radio siempre será r=5 por conveniencia

# Queremos aproximar un círculo con curvas de Hermite. 
# En clases se vio que para esto puedo tomar un cuarto de circunferencia, aproximar allí, y luego concatenar las curvas

# Creando una curva de Hermite
# Definimos los puntos
# Sea el radio del círculo=r
# la tangente es k, y se calculará como lo visto en clases

def crear_pirueta(punto):
    # quiero que el radio sea 5
    r = 5
    k = (5/0.25)*(math.sqrt(2)-1)

    P1 = np.array([[punto[0], punto[1], punto[2]]]).T
    P2 = np.array([[punto[0]-r, punto[1], punto[2]+r]]).T
    T1 = np.array([[0, 0, int(k)]]).T
    T2 = np.array([[int(k), 0, 0]]).T

    # Creamos la curva
    GMh = hermiteMatrix(P1, P2, T1, T2)
    HermiteCurve1 = evalCurve(GMh, auxiliar.M)

    # Segunda curva
    P1 = np.array([[punto[0]-r, punto[1], punto[2]+r]]).T
    P2 = np.array([[punto[0]-(2*r), punto[1], punto[2]]]).T
    T1 = np.array([[int(k), 0, 0]]).T
    T2 = np.array([[0, 0, -int(k)]]).T

    GMh = hermiteMatrix(P1, P2, T1, T2)
    HermiteCurve2 = evalCurve(GMh, auxiliar.M)

    # Tercera
    P1 = np.array([[punto[0]-(2*r), punto[1], punto[2]]]).T
    P2 = np.array([[punto[0]-r, punto[1], punto[2]-r]]).T
    T1 = np.array([[0, 0, -int(k)]]).T
    T2 = np.array([[-int(k), 0, 0]]).T

    GMh = hermiteMatrix(P1, P2, T1, T2)
    HermiteCurve3 = evalCurve(GMh, auxiliar.M)

    # Cuarta
    P1 = np.array([[punto[0]-r, punto[1], punto[2]-r]]).T
    P2 = np.array([[punto[0], punto[1], punto[2]]]).T
    T1 = np.array([[-int(k), 0, 0]]).T
    T2 = np.array([[0, 0, int(k)]]).T

    GMh = hermiteMatrix(P1, P2, T1, T2)
    HermiteCurve4 = evalCurve(GMh, auxiliar.M)

    # Concatenamos en una sola
    HermiteCurve = np.concatenate((HermiteCurve1, HermiteCurve2, HermiteCurve3, HermiteCurve4), axis=0)
    # y este será el recorrido de la nave para la pirueta.

    return HermiteCurve

# Ahora vemos los eventos
@controller.event
def on_key_press(symbol, modifiers):
    if symbol == pyglet.window.key.W:
        if auxiliar.modo_teclas ==1:
            auxiliar.advance = -1
    elif symbol == pyglet.window.key.S:
        if auxiliar.modo_teclas ==1:
            auxiliar.advance = 1
    elif symbol == pyglet.window.key.A:
        auxiliar.rotate_xy = 1
    elif symbol == pyglet.window.key.D:
        auxiliar.rotate_xy = -1
    elif symbol == pyglet.window.key.R:
        punto = np.array([auxiliar.eye[0],auxiliar.eye[1],auxiliar.eye[2]])
        #orientacion = debo ver los ángulos theta y phi asociados 
        # angulo phi es auxiliar.rotation_XY
        # angulo theta es auxiliar.rotation_XZ
        orientacion = np.array([auxiliar.rotation_XY%360,auxiliar.rotation_XZ%360])
        print("Punto agregado exitosamente: "+str(punto))
        print("La orientación de dicho punto es "+ "plano XY= " + str(auxiliar.rotation_XY%360) + ", plano XZ= " + str(auxiliar.rotation_XZ%360))
        lista_puntos.append(punto)
        lista_orient.append(orientacion)
        print(lista_puntos)
        #SE DEBEN REGISTRAR 1+3K PUNTOS (K NATURAL) (un aux me dijo que es legal)
        # Si se registra otra cantidad, podría calcular la curva pero va a ignorar los últimos puntos registrados
        # Por lo que mejor indicaremos cuántos puntos faltan
        print("la cantidad actual de puntos es: "+str(len(lista_puntos)))
    elif symbol == pyglet.window.key.C:
        if camera.C_KEY == False:
            camera.set_projection(PERSPECTIVE_PROJECTION)
            camera.C_KEY = True
        else: 
            camera.set_projection(ORTOGRAPHIC_PROJECTION)
            camera.C_KEY = False
    elif symbol == pyglet.window.key.V:
        # Si la nave se está recorriendo POR FAVOR ESPERAR A QUE SE TERMINE DE RECORRER
        if auxiliar.V_KEY == False:
            # Es decir, solo dibuja si no se ha dibujado antes
            if len(lista_puntos)==4:

                P0 = np.array([lista_puntos[0]]).T
                P1 = np.array([lista_puntos[1]]).T
                P2 = np.array([lista_puntos[2]]).T
                P3 = np.array([lista_puntos[3]]).T

                # Creamos la curva
                M1 = bezierMatrix(P0, P1, P2, P3)
                BezierCurve = evalCurve(M1, auxiliar.N//2)
                auxiliar.curva = BezierCurve
            elif len(lista_puntos)%3 == 1:
                # la cantidad de puntos registrados debe ser 1+3k, donde k es un número natural (para este caso mayor a 1)
                p = 0
                lista_curvas = list()
                while (p+3) < len(lista_puntos):
                    P0 = np.array([lista_puntos[p]]).T
                    P1 = np.array([lista_puntos[p+1]]).T
                    P2 = np.array([lista_puntos[p+2]]).T
                    P3 = np.array([lista_puntos[p+3]]).T

                    # creo curva
                    M1 = bezierMatrix(P0, P1, P2, P3)
                    BezierCurve1 = evalCurve(M1, auxiliar.N//2)

                    lista_curvas.append(BezierCurve1)

                    p+=3
                BezierCurve = np.concatenate(lista_curvas, axis=0)
                auxiliar.curva = BezierCurve

            esfera = createGPUShape(controller.pipeline,read_OBJ(ASSETS["esfera_obj"], (0,0,0)))
            lista_esferas = list()
            for i in range(0,len(auxiliar.curva)):
                #dibujo una esfera en esa posicion
                esfera_linea = sg.SceneGraphNode("esfera_linea")
                esfera_linea.transform = tr.matmul([tr.translate(auxiliar.curva[i,0],auxiliar.curva[i,1],auxiliar.curva[i,2]), tr.scale(0.05,0.05,0.05)])
                lista_esferas.append(esfera_linea)

            for punto in lista_esferas:
                punto.childs += [esfera]
                world_final.childs += [punto]
            
            auxiliar.V_KEY = True
            # acabo de dibujar la línea asociada a la curva

    elif symbol == pyglet.window.key._1:
        if len(lista_puntos)==4:

            P0 = np.array([lista_puntos[0]]).T
            P1 = np.array([lista_puntos[1]]).T
            P2 = np.array([lista_puntos[2]]).T
            P3 = np.array([lista_puntos[3]]).T

            # Creamos la curva
            M1 = bezierMatrix(P0, P1, P2, P3)
            BezierCurve = evalCurve(M1, auxiliar.N//2)
            auxiliar.hola = 1
            auxiliar.curva = BezierCurve
            auxiliar.N = auxiliar.N//2
        elif len(lista_puntos)>4 and len(lista_puntos)%3 == 1:
            # la cantidad de puntos registrados debe ser 1+3k, donde k es un número natural (para este caso mayor a 1)
            # luego, creo una cantidad(len(lista_puntos)//3) de curvas y las concateno
            if len(lista_puntos)<7:
                auxiliar.cant_curvas = 1
            else:
                # con 7 tengo 1, con 8 tengo 1, con 9 tengo 1, con 10 tengo 3
                auxiliar.cant_curvas = (len(lista_puntos)-1)//3
            p = 0
            lista_curvas = list()
            while (p+3) < len(lista_puntos):
                P0 = np.array([lista_puntos[p]]).T
                P1 = np.array([lista_puntos[p+1]]).T
                P2 = np.array([lista_puntos[p+2]]).T
                P3 = np.array([lista_puntos[p+3]]).T

                # creo curva
                M1 = bezierMatrix(P0, P1, P2, P3)
                BezierCurve1 = evalCurve(M1, auxiliar.N//2)

                lista_curvas.append(BezierCurve1)

                p+=3
            BezierCurve = np.concatenate(lista_curvas, axis=0)
            auxiliar.hola = 1
            auxiliar.curva = BezierCurve
            auxiliar.N = auxiliar.cant_curvas*auxiliar.N//2
            
        else:
            if len(lista_puntos) < 4:
                print("ERROR: Por favor ingresar "+ str((4-len(lista_puntos))) +" punto/s más")
            else:
                #len(lista_puntos) >4
                print("ERROR: Por favor ingresar "+ str(3-((len(lista_puntos)-1)%3)) +" punto/s más")


    elif symbol == pyglet.window.key.P:
        puntito = (auxiliar.eye[0],auxiliar.eye[1],auxiliar.eye[2])
        auxiliar.pirueta = crear_pirueta(puntito)
        auxiliar.modo_pirueta = 1
        pass


@controller.event
def on_key_release(symbol, modifiers):
    if symbol == pyglet.window.key.W:
        auxiliar.advance = 0
    elif symbol == pyglet.window.key.S:
        auxiliar.advance = 0
    elif symbol == pyglet.window.key.A:
        auxiliar.rotate_xy = 0
    elif symbol == pyglet.window.key.D:
        auxiliar.rotate_xy = 0

    elif symbol == pyglet.window.key.ESCAPE:
        controller.close()


@controller.event
# dibujamos todo
def on_draw():
    controller.clear()

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    # Agregamos los step para tener la cuena de las iteraciones
    # Si step es mayor a N, reseteamos su cuenta


    auxiliar.update()
    camera.update(auxiliar.eye)

    view = tr.lookAt(
        camera.eye,
        camera.at,
        camera.up
    )

    if camera.C_KEY == True:
        # por simpleza, voy a decir que la cámara va pegada a la nave chica
        pos_navechica = sg.findPosition(naves, "nave_pequena", parentTransform=tr.identity())
        pos_camara = pos_navechica.T[0]
        
        # redefinimos view
        view = tr.lookAt(
            pos_camara[0:3],
            camera.at,
            camera.up,
        )

    glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "projection"), 1, GL_TRUE, camera.projection)
    glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "view"), 1, GL_TRUE, view)

    if controller.showAxis:
        glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "model"), 1, GL_TRUE, tr.identity())
        controller.pipeline.drawCall(gpuAxis, GL_LINES)

    naves.transform = tr.matmul([tr.translate(auxiliar.transf[0],auxiliar.transf[1],auxiliar.transf[2]),tr.rotationZ(np.deg2rad(auxiliar.rotation_XY)),tr.rotationY(np.deg2rad(auxiliar.rotation_XZ))])
    sombras.transform = tr.matmul([tr.translate(auxiliar.transf[0],auxiliar.transf[1],auxiliar.transf[2]),tr.rotationZ(np.deg2rad(auxiliar.rotation_XY)),tr.rotationY(np.deg2rad(auxiliar.rotation_XZ))])
    
    if auxiliar.hola == 1:
        auxiliar.modo_teclas = 0
        if controller.step >= (auxiliar.N)-1:
            controller.step = 0
            auxiliar.modo_teclas = 1
            auxiliar.hola = 0
            auxiliar.N = 500

        controller.step += 1

        naves.transform = tr.matmul([
            tr.translate(auxiliar.curva[controller.step, 0], auxiliar.curva[controller.step, 1], auxiliar.curva[controller.step, 2]),
        ])
        sombras.transform = tr.matmul([
            tr.translate(auxiliar.curva[controller.step, 0], auxiliar.curva[controller.step, 1], auxiliar.curva[controller.step, 2])
        ])


        # misión de ahora: que la cámara se mueva con la nave mientras se mueve en la curva
        auxiliar.eye[0] = auxiliar.curva[controller.step, 0]
        auxiliar.eye[1] = auxiliar.curva[controller.step, 1]
        auxiliar.eye[2] = auxiliar.curva[controller.step, 2]

        # tengo las orientaciones
        # lista_orient[0] es la orientacion del punto 1
        # este fue mi intento de que la curva se recorriera con orientaciones pero no me funcionó y no me quedó tiempo para arreglarlo :c
        # además que considera solamente los puntos dentro de la lista de puntos, y para bezier solo me asegura el primero y el último
        # la idea 2 considera todos los de la interpolación pero queda feo
        indice = -1
        for punto in lista_puntos:
            indice +=1
            orientaciones = lista_orient[indice]
            angulo_XY = orientaciones[0]
            angulo_XZ = orientaciones[1]
            if auxiliar.eye[0] == punto[0] and auxiliar.eye[1] == punto[1] and auxiliar.eye[2] == punto[2]:
                print("llegué al punto")
                naves.transform = tr.matmul([
                    tr.translate(auxiliar.curva[controller.step, 0], auxiliar.curva[controller.step, 1], auxiliar.curva[controller.step, 2]),
                    tr.rotationZ(np.deg2rad(angulo_XY)),tr.rotationY(np.deg2rad(angulo_XZ))
                ])

        # idea 2:
        punto_anterior = lista_puntos[0]
        #lista_tangentes = list()
        for i in range(0,len(auxiliar.curva)):
            punto = np.array([auxiliar.curva[i,0], auxiliar.curva[i,1], auxiliar.curva[i,2]])
            tangente_anterior = punto - punto_anterior
            #lista_tangentes.append(tangente_anterior)
            # esta tangente debería ser al lugar donde apunta la nave en ese momento de la traslación
            # determinemos sus rotaciones
            tan_ejex = tangente_anterior[0]
            tan_ejey = tangente_anterior[1]
            tan_ejez = tangente_anterior[2]
            #tan_R = np.sqrt(np.square(tan_ejex) + np.square(tan_ejey) + np.square(tan_ejez))
            #tan_theta = np.arccos(tan_ejez/tan_R)
            #tan_phi = np.arctan(tan_ejey/tan_ejex)
            #naves.transform = tr.matmul([
            #    tr.translate(auxiliar.curva[controller.step, 0], auxiliar.curva[controller.step, 1], auxiliar.curva[controller.step, 2]),
            #    tr.rotationZ(tan_phi),tr.rotationY(tan_theta)
            #])
            punto_anterior = punto

            # aquí como que tomaba una rotación y se quedaba con ella todo el rato, no iba variando con los puntos
            # y en general estaba raro y se ralentizaba mucho
            # así que tampoco funcionó :c

        glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "model"), 1, GL_TRUE, naves.transform) 


    if auxiliar.modo_pirueta == 1:
        # para de moverse
        auxiliar.advance = 0
        # desactiva el modo teclas
        auxiliar.modo_teclas = 0
        auxiliar.M=100
        angulo_XY = copy.copy(auxiliar.rotation_XY)
        if controller.step >= (auxiliar.M)-1:
            controller.step = 0
            auxiliar.modo_pirueta = 0
            auxiliar.M=25
            auxiliar.modo_teclas = 1


        controller.step += 1

        naves.transform = tr.matmul([
            tr.translate(auxiliar.pirueta[controller.step, 0], auxiliar.pirueta[controller.step, 1], auxiliar.pirueta[controller.step, 2]),
            tr.rotationZ(np.deg2rad(angulo_XY)),tr.rotationY(np.deg2rad(auxiliar.rotation_XZ))
        ])

        sombras.transform = tr.matmul([
            tr.translate(auxiliar.pirueta[controller.step, 0], auxiliar.pirueta[controller.step, 1], auxiliar.pirueta[controller.step, 2]),
            tr.rotationZ(np.deg2rad(angulo_XY)),tr.rotationY(np.deg2rad(auxiliar.rotation_XZ))
        ])

        glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "model"), 1, GL_TRUE, naves.transform)
        pass

    sg.drawSceneGraphNode(world_final,controller.pipeline, "model")

    glUniformMatrix4fv(glGetUniformLocation(controller.pipeline.shaderProgram, "model"), 1, GL_TRUE, tr.identity())

# Este es el comando de la acción del mouse
controller.on_mouse_motion = auxiliar.update_circle


if __name__ == '__main__':
    pyglet.app.run()